import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class explosion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Explosion extends Actor
{
    //adds in an array to contain the images for explosion
    private GreenfootImage[] explosion = new GreenfootImage[29];
    //adds in the variables for explosion
    private int index = 0;
    private int delay = 0;
    public Explosion()//fills the array with images
    {
        for(int i = 0; i < explosion.length; i++){
            explosion[i] = new GreenfootImage("Explosion" + i + ".gif");
        }
    }
    /**
     * Act - do whatever the explosion wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() //makes the explosion class function
    {
        delay++;
        explode();
        dealDamage();
        remove();
    } 
    
    private void explode()//method that animates explosion
    {
        if(delay%1 == 0){
            setImage(explosion[index%explosion.length]);
            index++;
        }
    }
    
    private void remove()//method that removes explosion from the world if it's over
    {
        if(index >= 29){
            getWorld().removeObject(this);
        }
    }
    
    private void dealDamage() //method uses a knight mutator to damage it
    {               
        List<Knight> knight = getWorld().getObjects(Knight.class);       
        if(isTouching(Knight.class)){            
            for(Knight k : knight){
                k.loseHealth();
            }
        }        
    }

}
