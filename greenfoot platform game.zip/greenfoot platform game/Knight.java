import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class Knight here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Knight extends Actor
{
    //adds in the set values of the game
    private static final int fallAccel = 1;
    private static final int jumpHeight = 50;
    private static final int startVelocity = 10;
    private static final int attackCooldown = 15;
    private static final int iFrames = 75;
    //adds in the variables of the game
    private int fallVelocity = 0;
    private int index= 0;
    private int delay = 0;
    private int idleIndex = 0;
    private int idleDelay = 0;
    private int imgNum = 0;
    private int attackTimer = 0;
    private int getXTimer = 0;
    private int life = 5;
    private int iFrameCounter = 0;
    //adds in the booleans of the game
    private boolean isCrouching;
    private boolean goingLeft;
    private boolean isFalling;
    private boolean isJumping;
    private boolean isAttacking;
    private boolean ableToAttack = true;
    private boolean invincible;
    private boolean touching;
    private boolean canTakeDamage = true;
    private boolean isDead;
    //adds in the arrays that will contain the sprites for the knight
    private GreenfootImage[] idle = new GreenfootImage[4];
    private GreenfootImage[] idleLeft = new GreenfootImage[4];
    private GreenfootImage[] run = new GreenfootImage[6];
    private GreenfootImage[] runLeft = new GreenfootImage[6];
    private GreenfootImage[] crouch = new GreenfootImage[4];
    private GreenfootImage[] crouchLeft = new GreenfootImage[4];
    private GreenfootImage[] jump = new GreenfootImage[4];
    private GreenfootImage[] jumpLeft = new GreenfootImage[4];
    private GreenfootImage[] fall = new GreenfootImage[2];
    private GreenfootImage[] fallLeft = new GreenfootImage[2];
    private GreenfootImage[] attack = new GreenfootImage[5];
    private GreenfootImage[] attackLeft = new GreenfootImage[5];
    private GreenfootImage[] attack2 = new GreenfootImage[6];
    private GreenfootImage[] attack2Left = new GreenfootImage[6];
    private GreenfootImage[] attack3 = new GreenfootImage[6];
    private GreenfootImage[] attack3Left = new GreenfootImage[6];
    private GreenfootImage[] explosion = new GreenfootImage[29];
    private GreenfootImage[] die = new GreenfootImage[7];
    private GreenfootImage[] dieLeft = new GreenfootImage[7];
    
    public Knight() //the knight constructor, fills all the arrays with images
    {
        GreenfootImage img = getImage(); 
        img.scale(150,112);
        setImage(img);
        for(int i = 0; i<idle.length; i++){ 
            idle[i] = new GreenfootImage("adventurer-idle-1-0" + i + ".png");
            idle[i].scale(150,112);
        }
        for(int i = 0; i<idleLeft.length; i++){ 
            idleLeft[i] = new GreenfootImage("adventurer-idle-1-0" + i + ".png");
            idleLeft[i].mirrorHorizontally();
            idleLeft[i].scale(150,112);
        }
        for(int i = 0; i<run.length; i++){ 
            run[i] = new GreenfootImage("adventurer-run-0" + i + ".png");
            run[i].scale(150,112);
        }
        for(int i = 0; i<runLeft.length; i++){ 
            runLeft[i] = new GreenfootImage("adventurer-run-0" + i + ".png");
            runLeft[i].mirrorHorizontally();
            runLeft[i].scale(150,112);
        }
        for(int i = 0; i<crouch.length; i++){
            crouch[i] = new GreenfootImage("adventurer-crouch-0" + i + ".png");
            crouch[i].scale(150,112);
        }
        for(int i = 0; i<crouchLeft.length; i++){
            crouchLeft[i] = new GreenfootImage("adventurer-crouch-0" + i + ".png");
            crouchLeft[i].mirrorHorizontally();
            crouchLeft[i].scale(150,112);
        }
        for(int i = 0; i<jump.length; i++){
            jump[i] = new GreenfootImage("adventurer-jump-0" + i + ".png");
            jump[i].scale(150,112);
        }
        for(int i = 0; i<jumpLeft.length; i++){
            jumpLeft[i] = new GreenfootImage("adventurer-jump-0" + i + ".png");
            jumpLeft[i].mirrorHorizontally();
            jumpLeft[i].scale(150,112);
        }
        for(int i = 0; i<fall.length; i++){
            fall[i] = new GreenfootImage("adventurer-fall-0" + i + ".png");
            fall[i].scale(150,112);
        }
        for(int i = 0; i<fallLeft.length; i++){
            fallLeft[i] = new GreenfootImage("adventurer-fall-0" + i + ".png");
            fallLeft[i].mirrorHorizontally(); 
            fallLeft[i].scale(150,112);
        }
        for(int i = 0; i<attack.length; i++){
            attack[i] = new GreenfootImage("adventurer-attack1-0" + i + ".png");
            attack[i].scale(150,112);
        }
        for(int i = 0; i<attackLeft.length; i++){
            attackLeft[i] = new GreenfootImage("adventurer-attack1-0" + i + ".png");
            attackLeft[i].mirrorHorizontally();
            attackLeft[i].scale(150,112);
        }
        for(int i = 0; i<die.length; i++){
            die[i] = new GreenfootImage("adventurer-die-0" + i + ".png");
            die[i].scale(150,112);
        }
        for(int i = 0; i<dieLeft.length; i++){
            dieLeft[i] = new GreenfootImage("adventurer-die-0" + i + ".png");
            dieLeft[i].mirrorHorizontally();
            dieLeft[i].scale(150,112);
        }
    }
    /**
     * Act - do whatever the Knight wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */

    
    public void act() //checks for movement / attack / death of the knight class
    {
        if(!isDead){            
            movement();
            checkFall();
            invincibility();
            attack();
            if(isJumping){
                isAttacking = false;
            }
            if(onGround()){
                isJumping = false;
            }
            if(life < 0){
                life = 0;
            }
            cooldown();            
            die();
        }
        if(isDead){
            World clouds = getWorld();
            Clouds world = (Clouds)clouds;
            world.defeat();
        }
    }   
    
    public boolean onGround() // returns if the knight is on the ground
    {
        Actor platform = getOneIntersectingObject(Platform.class);
        return platform != null;
    }   
    
    public boolean getIsAttacking() // returns if the knight is attacking
    {
        return isAttacking;
    }
    
    public boolean getGoingLeft()  // returns if the knight is going left
    {
        return goingLeft;
    }
        
    private void movement() //handles / checks all movement and actions of the knight
    {
        if(Greenfoot.isKeyDown("s")){
            crouch();
        }
        else if(Greenfoot.isKeyDown("j")){
            if(ableToAttack && !isAttacking){  
                index = 0;
                delay = 0;                
                isAttacking = true;      
                attack();
                
            }
        }

        else if(Greenfoot.isKeyDown("space")&&!isJumping){
            isJumping = true;
            jump();
            isCrouching = false;
            isAttacking = false;
        }
        else if(Greenfoot.isKeyDown("a")&&!isJumping){               
            goLeft();
            isCrouching = false;
            goingLeft = true;
            isAttacking = false;
        }
        else if(Greenfoot.isKeyDown("d")&&!isJumping){
            goRight();
            isCrouching = false;
            goingLeft = false;
            isAttacking = false;
        }
        else {
            idle();
            isCrouching = false;
            isAttacking = false;
        } 
        if(isJumping && (Greenfoot.isKeyDown("a")||Greenfoot.isKeyDown("d"))){
            fallMove();
        }
    }    
    
    private void goLeft() //method to make the knight run left
      {                
        move(-3);
        if(delay%6 == 0){
            setImage(runLeft[index % runLeft.length]);
            index++;
        }
        delay++;
    }  
    
    private void goRight() //method to make the knight run right
    {
        move(3);
        if(delay%6 == 0){
            setImage(run[index % run.length]);
            index++;
        }
        delay++;
    }  
    
    private void jump() //method to initiate jumping for the knight
    {
        if(delay >= 20){
            delay = 0;
        }
        if(onGround()){
            fallVelocity = -20;
        }
        fall();
        if(isJumping && !goingLeft){
            if(delay%10 == 0){
                setImage(jump[index % jump.length]);
                index++;
            }
        } 
        else if (isJumping && goingLeft){
            if(delay%10 == 0){
                setImage(jumpLeft[index % jumpLeft.length]);
                index++;
            }
        }
        delay++;       
    }    
    
    private void fall() //method that allows the kngiht to fall in the air
    {
        if (onGround() == false){
            fallVelocity = fallVelocity + fallAccel;
        }
        setLocation(getX(),getY()+fallVelocity);
        if(fallVelocity < 0){
            isJumping = true;
            isFalling = true;
        } 
    } 
    
    private void fallMove() // method that allows the knight to move while falling
    {
        delay++;
        if (!goingLeft && isFalling){
            move(5);
            if(delay%10 == 0){
                setImage(fall[index%fall.length]);
                index++;
            }
        } 
        else if (goingLeft && isFalling){
            move(-5);
            if(delay%10 == 0){
                setImage(fallLeft[index%fallLeft.length]);
                index++;
            }
        }
        if(index >= fall.length){
            index = 0;
        }
    }
    
    private void crouch() //method that allows the knight to crouch
    {
        if(delay%8 == 0 && !goingLeft && (!isFalling || !isJumping)){
            setImage(crouch[index%crouch.length]);
            index++;
        }
        else if (delay%8 == 0 && goingLeft && (!isFalling || !isJumping)){
            setImage(crouchLeft[index%crouchLeft.length]);
            index++;
        }
        delay++;
    }   
    
    private void idle() //method that animates the knight when it's idle
    { 
        if(delay%10 == 0 && !goingLeft && (!isFalling || !isJumping)){
            setImage(idle[index % idle.length]);
            index++;
        }
        else if (delay%10 == 0 && goingLeft && (!isFalling || !isJumping)){
            setImage(idleLeft[index%idle.length]);
            index++;
        }
        delay++;
    }    

    private void checkFall() // method that checks if the knight is falling and makes it fall if it should be
    {
        if(onGround()) {
            fallVelocity = 0;
        }
        else if (onGround() == false) {
            fall();
        }
    }
    
    private void checkCrouch() //method that checks if the knight is crouching
    {
        if (!isCrouching) {
            index=0;
            delay=0;
            isCrouching=true;
        }
    }
    
    private void attack() //method that initiate the attack animation for the knight and allows it to damage enemies
    {
        if (isAttacking && ableToAttack){           
            boolean armourInRange = ! getObjectsInRange(100, Armour.class).isEmpty();
            boolean wraithInRange = ! getObjectsInRange(100, Wraith.class).isEmpty();
            swing();
            if(armourInRange){
                List<Armour> armour = getObjectsInRange(100, Armour.class);
                for(Armour a : armour){
                    a.damage();
                }
            }
            if(wraithInRange){
                List<Wraith> wraith = getObjectsInRange(100, Wraith.class);
                for(Wraith w : wraith){
                    w.damage();
                }
            }
        } 
    }
    
    private void swing() //method that animates the knight's attack
    {
        delay++;
        if(delay%4 == 0 && !goingLeft && !isJumping){
            setImage(attack[index%attack.length]);
            index++;
            if(Greenfoot.isKeyDown("d")){
                move(3);
            }
        }
        if(delay%4 == 0 && goingLeft && !isJumping){
            setImage(attackLeft[index%attackLeft.length]);
            index++;
            if(Greenfoot.isKeyDown("a")){
                move(-3);
            }
        }
        if(index == attack.length){
            isAttacking = false;
            ableToAttack = false;
        }
    }
    
    private void cooldown() //method that gives a cooldown to the knight between attacks
    {
        if(!ableToAttack){
            attackTimer++;
        }
        if(attackTimer == attackCooldown){
            ableToAttack = true;
            attackTimer = 0;
        }
    }
    
    public void loseHealth() //mutator that allows other classes to damage the knight and updates the life scoreboard
    {
        if(canTakeDamage){
            life--;
            invincible = true;
            World clouds = getWorld();
            Clouds world = (Clouds)clouds;
            world.minusLife();
        }
    }
    
    private void invincibility() //method that makes the knight invincible for a while after it is hit
    {
        if(invincible) {
            iFrameCounter++;
            canTakeDamage = false;
        }
        if(iFrameCounter >= iFrames){
            invincible = false;
            iFrameCounter = 0;
            canTakeDamage = true;
        }
    }
    
    private void die() //method that animates the knight dying 
    {
        if(life == 0){
            delay++;
            if(index >= die.length){
                index = 0;
                delay = 0;
            }
            if(delay%5 == 0 && !goingLeft){
                setImage(die[index%die.length]);
                index++;
            }
            else if(delay%5 == 0 && goingLeft){
                setImage(dieLeft[index%dieLeft.length]);
                index++;
            }
            if(index == die.length){
                isDead = true;
            }
        }
    }
    
}
