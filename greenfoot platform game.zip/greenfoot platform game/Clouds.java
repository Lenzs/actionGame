import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class Clouds here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Clouds extends World
{
    //adds in the boolean of the world
    private boolean title = true;
    //adds in variables in the world
    private int armourCount = 0;
    private int wraithCount = 0;
    private int count = 0;
    private int wave = 0;
    private int knightLife = 5;
    //adds in scoreboard in the world
    private Scoreboard Life =  new Scoreboard("Life", knightLife);
    private Scoreboard Wave = new Scoreboard("Wave", wave);

    /**
     * Constructor for objects of class Clouds.
     * 
     */
    public Clouds() //creates the world
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1400, 600, 1); 
        GreenfootImage bg = new GreenfootImage("clouds-resized.png"); 
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
        prepare();
    }
    
    public void act()//checks for the initiation of the game and updates scoreboards
    {
        List<Armour> armour = getObjects(Armour.class);
        if(title && Greenfoot.isKeyDown("space")){
            List<Text> text = getObjects(Text.class);
            removeObjects(text);
            setStage();
            title = false;
            wave = 1;
            Wave.addWave(wave);
        }                  
        count++;  
        spawnWaves();
        Wave.update();
        Life.update();
    }
    
    private void spawnWaves()//updates the waves and spawns in enemies and checks if the game has been won
    {
        boolean noArmour = getObjects(Armour.class).isEmpty();
        boolean noWraith = getObjects(Wraith.class).isEmpty();
        if(wave == 1){
            if(count%200 == 0 && armourCount < 3){
                if(Greenfoot.getRandomNumber(2) == 0){
                    addObject(new Armour(true), 0, 505);
                    armourCount++;
                }
                else {
                    addObject(new Armour(false), getWidth(), 505);
                    armourCount++;
                }
            }        
            if(count > 600 && noArmour){
                wave++;
                Wave.addWave(wave);
                count = 0;
            }
         }
         if(wave == 2){
            if(count%250 == 0 && wraithCount < 1){
                if(Greenfoot.getRandomNumber(2) == 0){
                    addObject(new Wraith(true), getWidth(), 505);
                    wraithCount++;
                }
                else {
                    addObject(new Wraith(false), 0, 505);
                    wraithCount++;
                }
            }
            if(count > 250 && noWraith){
                wave++;
                Wave.addWave(wave);
                count = 0;
            }
         }
         if(wave == 3){
             if(count%200 == 0 && armourCount < 5){
                if(Greenfoot.getRandomNumber(2) == 0){
                    addObject(new Armour(true), 0, 505);
                    armourCount++;
                }
                else {
                    addObject(new Armour(false), getWidth(), 505);
                    armourCount++;
                }
            }
            if(count == 400){
                addObject(new Wraith(true), getWidth(), 505);
                addObject(new Wraith(false), 0, 505);
            }
            if(count > 1000 && noWraith && noArmour){
                wave++;
                count = 0;
            }
         }
         if(wave == 4)
         {
             win();
         }
    }
    
    private void win()//displays the victory text
    {
        addObject(new Text(true), getWidth()/2, getHeight()/2);
    }
    
    public void defeat()//removes enemies and displays the defeat text
    {
        List<Wraith> wraith = getObjects(Wraith.class);
        List<Armour> armour = getObjects(Armour.class);
        removeObjects(wraith);
        removeObjects(armour);   
        addObject(new Text(false), getWidth()/2, getHeight()/2);
    }
    
    private void setStage()//sets the scoreboards and knight class if the game has been initialized
    {
        addObject(Life, 100, getHeight() - 15);
        addObject(Wave, 175, getHeight() - 15);

        addObject( new Knight(), getWidth()/2, 505 );

    }
    
    public void minusLife()//allows the updating of the life scoreboard
    {
        Life.loseLife();
        knightLife--;
    }
    
    private void prepare()//intializes the world
    {
       setPaintOrder(Scoreboard.class, Text.class, Explosion.class, Knight.class, Fireball.class, Armour.class, Wraith.class, Platform.class);
        addObject( new Platform(),125,590 );
        addObject( new Platform(),375,590 );
        addObject( new Platform(),625,590 );
        addObject( new Platform(),875,590 );
        addObject( new Platform(),1125,590 );
        addObject( new Platform(),1375,590 );
       addObject( new Text(), getWidth()/2, getHeight()/2);
    }
    
    
}
