import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class Armour here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Armour extends Actor
{
    //adds in the arrays to contain sprites for armour
    private GreenfootImage[] walk = new GreenfootImage[8];
    private GreenfootImage[] walkRight = new GreenfootImage[8];
    private GreenfootImage[] attack = new GreenfootImage[10];
    private GreenfootImage[] attackRight = new GreenfootImage[10];
    //adds in the set values for armour
    private static final int attackCooldown = 60;
    private static final int iFrames = 25;
    //adds in all the variables for armour
    private int knightX;
    private int delay = 0;
    private int index = 0;
    private int attackTimer = 0;
    private int life = 3;
    private int iTimer = 0;
    private int tValue = 255;
    //adds in all the booleans for armour
    private boolean isLeft;
    private boolean shouldAttack = false;
    private boolean isAttacking;
    private boolean ableToAttack =true;
    private boolean gettingHit;
    private boolean canTakeDamage = true;
    private boolean knightDirection;
    private boolean isDying;
    

    /**
     * Act - do whatever the Armour wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public Armour(boolean goingLeft) //constructor of the armour class, fills arrays with images
    {
        for(int i = 0; i<walk.length; i++){
            walk[i] = new GreenfootImage("Left" + i + ".png");
            walk[i].scale(125,112);
        }
        for(int i = 0; i<walkRight.length; i++){
            walkRight[i] = new GreenfootImage("Left" + i + ".png");
            walkRight[i].mirrorHorizontally();
            walkRight[i].scale(125,112);
        }
        for(int i = 0; i<attack.length; i++){
            attack[i] = new GreenfootImage("LeftAttack" + i + ".png");
            attack[i].scale(125,112);
        }
        for(int i = 0; i<attackRight.length; i++){
            attackRight[i] = new GreenfootImage("LeftAttack" + i + ".png");
            attackRight[i].mirrorHorizontally();
            attackRight[i].scale(125,112);
        }
    }
    public void act() //checks for movement /death / invincibility for the armour class 
    {
        if(!isDying){
            move();
            turn();
            chooseToAttack();
            chooseDirection();
            invincible();
            delay++;
        }
        die();
    }    
    private void move() // method that allows the armour to move
    {
        if(isLeft&&!isAttacking){
            move(-1);
            if(delay%5 == 0){
                setImage(walk[index%walk.length]);
                index++;
            }
        }
        else if(!isLeft&&!isAttacking){
            move(1);
            if(delay%5 == 0){
                setImage(walkRight[index%walkRight.length]);
                index++;
            }
        }
    }
    private void turn() //method that allows the armour to turn around if it has hit an edge
    {
        if(isAtEdge()){
            if(isLeft){
                isLeft = false;
            }
            else if (!isLeft){
                isLeft = true;
            }
        }
    }
    private void attack() //method that animates the armour's attack and handles cooldown for attacking
    {
        if(index > attack.length){
            index = 0;
            delay = 0;
        }
        if(delay%4 == 0 && isLeft && ableToAttack){
            isAttacking = true;
            setImage(attack[index%attack.length]);
            index++;
        }
        if(delay%4 == 0 && !isLeft && ableToAttack){
            isAttacking = true;
            setImage(attackRight[index%attackRight.length]);
            index++;
        }
        if(index == attack.length){
            shouldAttack = false;
            isAttacking = false;
            ableToAttack = false;
        }
        if(!ableToAttack){
            attackTimer++;
        }
        if(attackTimer == attackCooldown){
            ableToAttack = true;
            attackTimer = 0;
        }
    }
    
    private void chooseToAttack() //method that checks if the knight is near and if the armour should attack, also responsible for calling mutator to damage the knight 
    {
        boolean knightInRange = ! getObjectsInRange(75, Knight.class).isEmpty();
        List<Knight> knight = getObjectsInRange(75, Knight.class);      
        if(knightInRange){
            Knight kt = (Knight)getOneIntersectingObject(Knight.class);
            knightDirection = kt.getGoingLeft();
            if( (knightDirection && !isLeft) || (!knightDirection && isLeft) ){
                shouldAttack = true;
            }
        } 
        if(shouldAttack){
            attack();            
            for(Knight k : knight){
                k.loseHealth();
            }
        }
    }
    
    private void chooseDirection() //method that makes the armour change directions randomly
    {
        if(isLeft && Greenfoot.getRandomNumber(750)==0){
            isLeft = false;
        }
        if(!isLeft && Greenfoot.getRandomNumber(750)==0){
            isLeft = true;
        }   
    }
    
    public void damage() //mutator that makes the armour take damage
    {
        if(canTakeDamage){
            life--;
            canTakeDamage = false;
        }
    }
    
    private void invincible() //method that give the armour i frames
    {
        if(!canTakeDamage){
            iTimer++;
            if(iTimer >= iFrames){
                canTakeDamage = true;
                iTimer = 0;
            }
        }
    }
    
    private void die() //method that removes the armour if it dies
    {
        if(life == 0){
            isDying = true;
            getImage().setTransparency(tValue);
            if(tValue > 0){
                tValue -= 5;
            }
            if(tValue <= 0){
                getWorld().removeObject(this);
            }
        }
    }


}
