import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class scoreboard here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Scoreboard extends Actor
{
    //adds in the images of the scoreboard and sets its contents
    GreenfootImage Scoreboard = new GreenfootImage(100,25);
    private String index;
    private int value;

    /**
     * Act - do whatever the scoreboard wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
    
    public Scoreboard(String indexText, int setValue){ //creates / draws the scoreboard
        index = indexText;
        value = setValue;
        update();
    }
    
    public void addWave(int wave){ //updates the wave scoreboard
        value = wave;
        update();
    }
    
    public void loseLife(){ //updates the life scoreboard
        value--;
        update();
    }
    
    public void update() //method that updates a scoreboard with new values
    {
        Scoreboard.setColor(Color.BLACK);
        Scoreboard.fill();
        Scoreboard.setColor(Color.WHITE);
        Scoreboard.drawString(index + ": " + value, 30, 15);
        setImage(Scoreboard);
    }
}
