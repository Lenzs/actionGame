import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Wraith here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Wraith extends Actor
{
    //adds in arrays to contain the wraith sprites
    private GreenfootImage[] move = new GreenfootImage[5];
    private GreenfootImage[] moveRight = new GreenfootImage[5];
    private GreenfootImage[] shoot = new GreenfootImage[10];
    private GreenfootImage[] shootRight = new GreenfootImage[10];
    private GreenfootImage[] die = new GreenfootImage[5];
    private GreenfootImage[] dieRight = new GreenfootImage[5];
    //adds the set values for the wraith
    private static final int cooldownTime = 250;
    private static final int iFrames = 25;
    //adds in booleans for the wraith
    private boolean isLeft;
    private boolean inPosition;
    private boolean attackCharged;
    private boolean canAttack = true;
    private boolean indexReset;
    private boolean hasAttacked;
    private boolean isDying = false;
    private boolean canTakeDamage = true;
    //adds in variables for the wraith
    private int delay = 0;
    private int index = 0;
    private int life = 3;
    private int cooldownTimer = 0;
    private int tValue = 255;
    private int iTimer = 0;
    
    /**
     * Act - do whatever the Wraith wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Wraith(boolean facingLeft)//fills the arrays with images
    {
        for( int i = 0; i<move.length; i++){
            move[i] = new GreenfootImage("wizF-" + i + ".png");
            move[i].scale(140,140);
        }
        for( int i = 0; i<moveRight.length; i++){
            moveRight[i] = new GreenfootImage("wizF-" + i + ".png");
            moveRight[i].mirrorHorizontally();
            moveRight[i].scale(140,140);
        }
        for( int i = 0; i<shoot.length; i++){
            shoot[i] = new GreenfootImage("wizI-" + i + ".png");
            shoot[i].scale(140,140);
        }
        for( int i = 0; i<shootRight.length; i++){
            shootRight[i] = new GreenfootImage("wizI-" + i + ".png");
            shootRight[i].mirrorHorizontally();
            shootRight[i].scale(140,140);
        }
        for( int i = 0; i<die.length; i++){
            die[i] = new GreenfootImage("wizD-" + i + ".png");
            die[i].scale(140,140);
        }
        for( int i = 0; i<dieRight.length; i++){
            dieRight[i] = new GreenfootImage("wizD-" + i + ".png");
            dieRight[i].mirrorHorizontally();
            dieRight[i].scale(140,140);
        }
        isLeft = facingLeft;
    }
    public void act() //checks for movement and death of the wraith
    {
        if(!isDying){
            move();
            shoot();
            invincible();
        }
        die();
    }    
    
    private void move()//method that moves / animates the wraith
    {
        if(isLeft && getX() > 1200){
            move(-2);
            delay++;
            if(delay%16 == 0){
                setImage(move[index%move.length]);
                index++;
            }
        }
        else if (!isLeft && getX() < 200){
            move(2);
            delay++;
            if(delay%16 == 0){
                setImage(moveRight[index%move.length]);
                index++;
            }
        }
        else{
            inPosition = true;
        }
    }
    
    private void shoot()//method that animates the wraith firing and sets delay / logistics of the firing process
    {
        if(inPosition){
            delay++;
            if(!indexReset ){
                index = 0;
                delay = 0;
                indexReset = true;
            }
            if(attackCharged && canAttack){
                getWorld().addObject(new Fireball(), getX()-26, getY()-16);
                canAttack = false;
                attackCharged = false;
                index = 0;
                delay = 0;
            }
            if(index == shoot.length){
                attackCharged = true;
            }
            if(attackCharged && !canAttack){
                if(delay%5 == 0 && isLeft){
                    setImage(shoot[shoot.length-1]);
                }
                else if(isLeft){
                    setImage(shoot[shoot.length-2]);
                }
                if(delay%5 == 0 && !isLeft){
                    setImage(shootRight[shootRight.length-1]);
                }
                else if(!isLeft){
                    setImage(shootRight[shootRight.length-2]);
                }
            }
            if(!canAttack){
                cooldownTimer++;
            }
            if(cooldownTimer == cooldownTime){
                canAttack = true;
                cooldownTimer = 0;
            }
            if(delay%10 == 0 && isLeft && !attackCharged){
                setImage(shoot[index%shoot.length]);
                index++;
            }
            else if(delay%10 == 0 && !isLeft && !attackCharged){
                setImage(shootRight[index%shootRight.length]);
                index++;
            }
        }
    }
    
    private void die() //method that animates the death of the wraith and removes it from the world
    {
        if(life <= 0){
            delay++;
            isDying = true;
            getImage().setTransparency(tValue);
            if(tValue > 0){
                tValue -= 5;
            }
            if(index==die.length){
                index = die.length;
            }
            if(isLeft && delay%10 == 0){
                setImage(die[index%die.length]);
                index++;
            }
            else if(!isLeft && delay%10 == 0){
                setImage(dieRight[index%dieRight.length]);
                index++;
            }
            if(tValue <= 0){
                getWorld().removeObject(this);
            }
        }
    }
    
    private void invincible()//method that makes the wraith invincible for a while after it takes damage
    {
        if(!canTakeDamage){
            iTimer++;
            if(iTimer >= iFrames){
                canTakeDamage = true;
                iTimer = 0;
            }
        }
    }
    
    public void damage() //method that allows the wraith to damage the knight
    {
        if(canTakeDamage){
            life--;
            canTakeDamage = false;
        }
    }
}
