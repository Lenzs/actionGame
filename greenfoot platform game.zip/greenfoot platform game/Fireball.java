import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class Fireball here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Fireball extends Actor
{
    //adds in booleans of Fireball
    private boolean isLeft;
    private boolean hasDirection;
    private boolean shouldBeRemoved;
    private boolean madeContact;
    private boolean hasExploded;
    private boolean exploding;
    //adds in variables of Fireball
    private int index = 0;
    private int delay = 0;
    private int explodeX;
    //adds in arrays to contain the Fireballs sprites
    private GreenfootImage[] fireball = new GreenfootImage[5];
    private GreenfootImage[] fireballLeft = new GreenfootImage[5];
    private GreenfootImage[] explosion = new GreenfootImage[29];
    /**
     * Act - do whatever the Fireball wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Fireball() //construct of Fireball, fills all the arrays with images
    {
        for(int i = 0; i < fireball.length; i++){
            fireball[i] = new GreenfootImage("Fire" + i + ".png");
        }
        for(int i = 0; i < fireballLeft.length; i++){
            fireballLeft[i] = new GreenfootImage("Fire" + i + ".png");
            fireballLeft[i].mirrorHorizontally();
        }
        hasDirection = false;
        shouldBeRemoved = false;
    }
    
    public void act() //checks for direction, moves and removes the fireball 
    {
        setDirection();
        delay++;
        move();
        explosion();
        checkRemoval();
    }   
    
    private void setDirection() //method to check and st the direction of Fireball
    {
        if(getX() > getWorld().getWidth()/2 && !hasDirection){
            isLeft = true;
            hasDirection = true;
        } 
        else if(getX() < getWorld().getWidth()/2 && !hasDirection){
            isLeft = false;
            hasDirection = true;
        }
    }
    
    private void move() //method to move Fireball
    {
        if(isLeft&&!exploding){
            move(-5);
            if(delay%4 == 0){
                setImage(fireballLeft[index%fireballLeft.length]);
                index++;
            }
        }
        if(!isLeft&&!exploding){
            move(5);
            if(delay%4 == 0){
                setImage(fireball[index%fireball.length]);
                index++;
            }
        }
    }
    
    private void explosion() //method that adds in a explosion when the Fireball makes contact with the Knight
    {
        
        if(isTouching(Knight.class) && !madeContact ){
            madeContact = true;
        }

        if(isLeft && madeContact){
            if(getX() <= explodeX - 60){
                getWorld().addObject(new Explosion(), getX(), getY());
                hasExploded = true;
            }
        }
        else if (!isLeft && madeContact){
            if(getX() >= explodeX + 60){
                getWorld().addObject(new Explosion(), getX(), getY());
                hasExploded = true;
            }
        } 
    }
    
    private void checkRemoval()//method that removes the fireball if its spawned in an explosion
    {
        if(isAtEdge() || hasExploded){
            shouldBeRemoved = true;
        }
        if(shouldBeRemoved){
            getWorld().removeObject(this);
        }
    }
}
