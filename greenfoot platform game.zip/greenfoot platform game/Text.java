import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class title here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Text extends Actor
{
    //adds in the image for text
    GreenfootImage text = new GreenfootImage(600,200);
    
    private boolean isVictory;
    /**
     * Act - do whatever the title wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Text() //draws the title screen
    {
        text.setColor(Color.BLACK);
        text.drawString("INVASION DEFENDER", 250, 10);
        text.drawString("Press Space To Begin", 250, 180);
        text.scale(1000,300);
        setImage(text);        
    }
    
    public Text(boolean victory)//draws the victory/defeat screen
    {
        isVictory = victory;
        if(isVictory){
            text.setColor(Color.BLACK);
            text.drawString("YOU WIN!!!", 250, 30);
            text.scale(1000,300);
            setImage(text);
        }
        if(!isVictory){
            text.setColor(Color.BLACK);
            text.drawString("YOU LOSE!!!", 250, 30);
            text.scale(1000,300);
            setImage(text);
        }
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
}
